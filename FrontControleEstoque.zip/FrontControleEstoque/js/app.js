// Ajuste a URL e porta de acordo com a sua API .NET no Visual Studio
const API_URL = 'http://localhost:5258/api';

document.addEventListener('DOMContentLoaded', () => {

    // 1. CARREGAR TOTAIS (Apenas no index.html)
    if (document.getElementById('total-produtos')) {
        carregarTotais();
    }

    // 2. FORMULÁRIO DE CATEGORIA (Apenas no categorias.html)
    const formCategoria = document.getElementById('form-categoria');
    if (formCategoria) {
        formCategoria.addEventListener('submit', async (e) => {
            e.preventDefault();
            const payload = {
                nome: document.getElementById('cat-nome').value,
                descricao: document.getElementById('cat-descricao').value
            };

            try {
                const res = await fetch(`${API_URL}/Categorias`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });
                if (res.ok) {
                    alert('✅ Categoria cadastrada com sucesso!');
                    formCategoria.reset();
                } else {
                    alert('❌ Erro ao cadastrar categoria.');
                }
            } catch (err) {
                alert('❌ Erro ao conectar com a API.');
            }
        });
    }

    // 3. FORMULÁRIO DE FORNECEDOR (Apenas no fornecedores.html)
    const formFornecedor = document.getElementById('form-fornecedor');
    if (formFornecedor) {
        formFornecedor.addEventListener('submit', async (e) => {
            e.preventDefault();
            const payload = {
                nome: document.getElementById('forn-nome').value,
                cnpj: document.getElementById('forn-cnpj').value,
                telefone: document.getElementById('forn-telefone').value,
                email: document.getElementById('forn-email').value
            };

            try {
                const res = await fetch(`${API_URL}/Fornecedores`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });
                if (res.ok) {
                    alert('✅ Fornecedor cadastrado com sucesso!');
                    formFornecedor.reset();
                } else {
                    alert('❌ Erro ao cadastrar fornecedor.');
                }
            } catch (err) {
                alert('❌ Erro ao conectar com a API.');
            }
        });
    }

    // 4. FORMULÁRIO DE PRODUTO (Apenas no produtos.html)
    // 4. FORMULÁRIO DE PRODUTO (Apenas no produtos.html)
const formProduto = document.getElementById('form-produto');
if (formProduto) {
    formProduto.addEventListener('submit', async (e) => {
        e.preventDefault();

        const payload = {
            produtoId: 0,
            nome: document.getElementById('prod-nome').value,
            preco: parseFloat(document.getElementById('prod-preco').value),
            quantidadeEstoque: parseInt(document.getElementById('prod-estoque').value),
            categoriaId: parseInt(document.getElementById('prod-categoria-id').value),
            fornecedorId: parseInt(document.getElementById('prod-fornecedor-id').value)
        };

        try {
            const res = await fetch(`${API_URL}/Produtos`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            if (res.ok) {
                alert('✅ Produto cadastrado com sucesso!');
                formProduto.reset();
            } else {
                // Captura a mensagem de erro exata vinda do .NET
                const errorData = await res.json();
                console.error('Detalhes do erro:', errorData);
                
                const mensagens = errorData.errors 
                    ? JSON.stringify(errorData.errors, null, 2) 
                    : errorData.title || 'Dados inválidos';

                alert(`❌ Erro no cadastro:\n${mensagens}`);
            }
        } catch (err) {
            alert('❌ Erro ao conectar com a API.');
        }
    });
}
});

// FUNÇÕES AUXILIARES DE BUSCA
async function carregarTotais() {
    fetchData(`${API_URL}/Produtos`, 'total-produtos');
    fetchData(`${API_URL}/Categorias`, 'total-categorias');
    fetchData(`${API_URL}/Fornecedores`, 'total-fornecedores');
}

async function fetchData(endpoint, elementId) {
    const elemento = document.getElementById(elementId);
    if (!elemento) return;

    try {
        const response = await fetch(endpoint);
        if (response.ok) {
            const data = await response.json();
            elemento.innerText = data.length;
        } else {
            elemento.innerText = '0';
        }
    } catch (error) {
        console.error(`Erro ao carregar ${endpoint}:`, error);
        elemento.innerText = '0';
    }
}